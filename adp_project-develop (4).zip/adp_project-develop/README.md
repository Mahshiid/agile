# EDA397 Agile Development Processes Demo Project

[![Build Status](https://travis-ci.org/magagr/adp_project.svg?branch=master)](https://travis-ci.org/magagr/adp_project)

Contains the meta level requirements for the project,
and a template for the report.
Both are in markdown format; the Travis build creates
pdf, docx, and tex.

