package com.recyclerush.group5.recyclerush;

import android.content.Context;
import android.widget.LinearLayout;

public class ScoreboardItem extends LinearLayout {
    public ScoreboardItem(Context context){
        super(context);
    }
}
